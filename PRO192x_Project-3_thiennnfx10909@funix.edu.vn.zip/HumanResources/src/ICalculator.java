/**
 * - Interface ICalculator: gồm hàm tính lương,
 *    quản lý implement ở manager và employee
 * */
interface ICalculator {
    double calculateSalary();
    }
